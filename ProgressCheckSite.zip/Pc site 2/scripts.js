window.onload = function() {
  window.scrollTo(0, 0);
};

function goToPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {//This is used to find "pages"//
      page.style.display = 'none';//this hides the pages once an answer has been selected//
    });
    document.getElementById(pageId).style.display = 'block';//This shows the pages//
  }
let string = '';
function RID(Addpic){
  string += Addpic;       //this section is used to create string codes, each code reffers to a different combination//
  print();
}
  
function print() {
  console.log(`string: ${string}`); //raw value in the console


// if string = *******  change div class = SM to a tag, link, button...//
  if (string === 'a1a3a4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+Z790+Carbon+WiFi+Noctua+Chromax+NZXT+H9+ELITE+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a1a3a4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+Z790+Carbon+WiFi+Noctua+Chromax+NZXT+H9+ELITE+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a1b3a4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+Z790+Carbon+WiFi+NZXT+Kraken+NZXT+H9+ELITE+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a1b3a4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+Z790+Carbon+WiFi+NZXT+Kraken+NZXT+H9+ELITE+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b1a3a4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ASUS+ROG+Maximus+Z790+Apex+Noctua+Chromax+NZXT+H9+ELITE+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b1a3a4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ASUS+ROG+Maximus+Z790+Apex+Noctua+Chromax+NZXT+H9+ELITE+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b1b3a4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ASUS+ROG+Maximus+Z790+Apex+NZXT+Kraken+NZXT+H9+ELITE+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b1b3a4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ASUS+ROG+Maximus+Z790+Apex+NZXT+Kraken+NZXT+H9+ELITE+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a2a3a4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+X670E+Tomahawk+Wifi+Noctua+Chromax+NZXT+H9+ELITE+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a2a3a4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+X670E+Tomahawk+Wifi+Noctua+Chromax+NZXT+H9+ELITE+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a2b3a4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+X670E+Tomahawk+Wifi+NZXT+Kraken+NZXT+H9+ELITE+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a2b3a4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+X670E+Tomahawk+Wifi+NZXT+Kraken+NZXT+H9+ELITE+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b2a3a4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ROG+STRIX+X670E-A+GAMING+WIFI+Noctua+Chromax+NZXT+H9+ELITE+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b2a3a4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ROG+STRIX+X670E-A+GAMING+WIFI+Noctua+Chromax+NZXT+H9+ELITE+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b2b3a4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ROG+STRIX+X670E-A+GAMING+WIFI+NZXT+Kraken+NZXT+H9+ELITE+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b2b3a4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ROG+STRIX+X670E-A+GAMING+WIFI+NZXT+Kraken+NZXT+H9+ELITE+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a1a3b4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+Z790+Carbon+WiFi+Noctua+Chromax+Corsair+4000D+Airflow+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a1a3b4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+Z790+Carbon+WiFi+Noctua+Chromax+Corsair+4000D+Airflow+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a1b3b4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+Z790+Carbon+WiFi+NZXT+Kraken+Corsair+4000D+Airflow+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a1b3b4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+Z790+Carbon+WiFi+NZXT+Kraken+Corsair+4000D+Airflow+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b1a3b4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ASUS+ROG+Maximus+Z790+Apex+Noctua+Chromax+Corsair+4000D+Airflow+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b1a3b4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ASUS+ROG+Maximus+Z790+Apex+Noctua+Chromax+Corsair+4000D+Airflow+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b1b3b4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ASUS+ROG+Maximus+Z790+Apex+NZXT+Kraken+Corsair+4000D+Airflow+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b1b3b4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ASUS+ROG+Maximus+Z790+Apex+NZXT+Kraken+Corsair+4000D+Airflow+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a2a3b4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+X670E+Tomahawk+Wifi+Noctua+Chromax+Corsair+4000D+Airflow+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a2a3b4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+X670E+Tomahawk+Wifi+Noctua+Chromax+Corsair+4000D+Airflow+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a2b3b4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+X670E+Tomahawk+Wifi+NZXT+Kraken+Corsair+4000D+Airflow+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'a2b3b4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=MSI+MAG+X670E+Tomahawk+Wifi+NZXT+Kraken+Corsair+4000D+Airflow+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b2a3b4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ROG+STRIX+X670E-A+GAMING+WIFI+Noctua+Chromax+Corsair+4000D+Airflow+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b2a3b4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ROG+STRIX+X670E-A+GAMING+WIFI+Noctua+Chromax+Corsair+4000D+Airflow+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b2b3b4a5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ROG+STRIX+X670E-A+GAMING+WIFI+NZXT+Kraken+Corsair+4000D+Airflow+RTX+4090&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else if (string === 'b2b3b4b5') {
    document.getElementById("SM").innerHTML = '<a href="https://www.google.com/search?q=ROG+STRIX+X670E-A+GAMING+WIFI+NZXT+Kraken+Corsair+4000D+Airflow+RX+7900XT&tbm=isch" target="_blank"><button>Click Here To See Builds Like Yours</button></a>';
  } else {
    document.getElementById("SM").innerHTML = '';
  }
}
// Chat gpt made all the individual path options, but I did give it the first few so it knows what do or the format.
// Because screw that sitting there manually entering all these paths//



